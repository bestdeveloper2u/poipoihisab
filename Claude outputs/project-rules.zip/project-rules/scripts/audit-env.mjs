#!/usr/bin/env node
/**
 * Environment variables, checked in BOTH directions.
 *
 * The forward direction is obvious: a variable the code reads that is missing
 * from the example file is a fresh clone that boots and then dies somewhere
 * unrelated.
 *
 * The reverse direction is the one people skip and the one that costs more. A
 * variable in the example file that nothing reads is dead config: it gets
 * copied into every real environment, set to a plausible value, and believed.
 * Somebody eventually changes it to fix something and nothing happens, which is
 * a worse afternoon than a missing variable.
 */
import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import { CODE, ROOT, config, read, reporter, walk } from './_lib.mjs';

const cfg = config();
const r = reporter('env');
const example = read(cfg.envExample);

if (example === null) {
  console.log(`— skipped: ${cfg.envExample} not found`);
  process.exit(0);
}

const declared = new Set();
for (const line of example.split('\n')) {
  const m = line.match(/^\s*(?:export\s+)?([A-Z][A-Z0-9_]*)\s*=/);
  if (m) declared.add(m[1]);
}

/* Read from source three ways, because every codebase uses at least two:
   process.env.X, process.env['X'], and a Zod/valibot-style schema key. */
const used = new Set();
const ignore = new Set(cfg.envIgnore);
let scanned = 0;

for (const dir of cfg.sourceDirs) {
  for (const file of walk(dir, (f) => CODE.test(f))) {
    scanned++;
    const src = readFileSync(join(ROOT, file), 'utf8');
    for (const m of src.matchAll(/process\.env\.([A-Z][A-Z0-9_]*)/g)) used.add(m[1]);
    for (const m of src.matchAll(/process\.env\[\s*['"]([A-Z][A-Z0-9_]*)['"]\s*\]/g)) used.add(m[1]);
    for (const m of src.matchAll(/import\.meta\.env\.([A-Z][A-Z0-9_]*)/g)) used.add(m[1]);
    // A schema object whose keys are SCREAMING_CASE is an env schema in every
    // codebase that has one; matching the key form rather than the library name
    // keeps this working when the library is swapped.
    for (const m of src.matchAll(/^\s*([A-Z][A-Z0-9_]{2,})\s*:\s*[a-z]/gm)) used.add(m[1]);
  }
}

for (const name of used) {
  if (ignore.has(name)) continue;
  if (!declared.has(name)) r.error(`${name} is read by the code but missing from ${cfg.envExample}`);
}
for (const name of declared) {
  if (ignore.has(name)) continue;
  if (!used.has(name)) r.error(`${name} is in ${cfg.envExample} but nothing reads it`);
}

console.log(`env: ${declared.size} declared, ${used.size} read, ${scanned} file(s) scanned`);
if (r.finish()) r.ok(`${cfg.envExample} and the code agree, in both directions`);

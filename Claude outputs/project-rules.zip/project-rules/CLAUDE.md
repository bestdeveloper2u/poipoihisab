# Working agreement

Read this fully. It is short on purpose. `ROADMAP.md` is the plan; this is how we
work on it.

Everything below exists because work outruns verification. Code is written faster
than it is checked, and a project dies at the point where nobody can say what is
actually true about it any more.

---

## The one rule

**One slice per session, finished.** A slice is done when it meets every
Definition-of-Done point below — not when the code is written. If a slice is too
big for a session, it was two slices.

Do not start a second slice. Do not "quickly also fix" something else. Do not
refactor and add a feature in the same session.

---

## Session start

1. `git pull`
2. `<pkg> run doctor` — one report of every toolchain problem, each with its fix.
   Run it before anything else. A wiring problem discovered one blocked commit at
   a time feels like a framework problem and invites a rewrite.
3. Read the slice's entry in `ROADMAP.md` — it gives UI, Does, Data, Done.
4. Check `STATUS.md` for what the slice already touches.

## Session end

1. `<pkg> run verify` — must pass.
2. Update `STATUS.md` in the same commit as the code.
3. Commit **and push**. Never end a session with unpushed commits.

---

## Definition of Done

A slice is done when all of these are true. Every point is binary — you either
did it or you did not.

1. **Renders correctly at 1440 / 980 / 375px.** Three widths, looked at.
2. **Every state handled**: loading, empty, error, populated, permission-denied.
3. **Every value comes from the data layer.** No fixtures, no hardcoded copy, no
   invented numbers.
4. **The seed populates it — you have seen it full.** A screen you have only seen
   empty is a screen you have not tested.
5. **Every mutation works, and its failure path shows a real message that says
   what did _not_ happen.**
6. **Authorisation enforced at every layer, with a test for the DENIED case.**
7. **The data layer's own access rules exist, with a test per role** — including
   the anonymous one.
8. **Types and contracts regenerated; everything that consumes them compiles.**
9. **`STATUS.md` updated in the same commit.**
10. **Committed and pushed.**

If a point does not apply to your project, delete it. Do not keep a point you
intend to skip — a Definition of Done with a decorative entry is a Definition of
Done nobody reads.

---

## Absolute constraints

These are not preferences. Breaking one is a defect regardless of whether tests
pass.

**This list starts short and grows from your own incidents.** Every entry must
name the failure that produced it, with a real count. "Three tables were found in
this state" is why a rule gets obeyed; "follow best practices" is why rules do
not. Add an entry the same day something breaks, or you will not add it.

The starting set — these hold in almost any application:

1. **One name per concept, everywhere** — schema, routes, UI copy and comments.
   Two names for one idea is how a model splits in half.
2. **Money is an integer in the smallest unit.** Never float. Convert to display
   units in exactly one place per direction. Retrofitting this later is a
   migration plus an audit of every arithmetic expression you own.
3. **Nothing is a fixture.** Every number and every string on every screen comes
   from the data layer. A hardcoded array looks identical today and still looks
   identical after the endpoint behind it breaks.
4. **Access rules ship with the table.** No table reaches the main branch without
   its policies and a test per role.
5. **A permission grant and its policy ship together, or neither ships.**
   Granting access you have not policied is worse than granting nothing:
   ungranted fails loudly on the first call, granted-and-unpolicied returns an
   empty result and fails on write — a screen that renders blank with nothing in
   the log.
6. **Restate conditions; never delegate them.** A rule that inherits another
   rule inherits every future widening of it. Fail closed.
7. **Contract first.** Nothing is implemented before its schema exists. If the
   contract changed, regenerate and make every consumer compile in the same
   commit.
8. **Sanitise on write, store sanitised, never render raw HTML.**
9. **Every outbound request goes through one wrapper**, with the SSRF guard at
   the socket after DNS resolution — never a string check on the hostname, which
   DNS rebinding walks straight through.
10. **A component with no styles is not built.**
11. **Decisions that are closed, stay closed.** Keep the list here, each with the
    date and the reasoning. Without it, every hard week reopens the stack choice.

---

## Scope

**Frozen per release.** Anything new that arrives mid-release becomes a
`BACKLOG.md` line and is considered at the next boundary. It is never merged into
the release in flight.

If asked to build something not in the current release, say so and add it to the
backlog rather than building it.

---

## Honesty requirements

- If you cannot run something, say so plainly. Unverified code is a draft, not a
  deliverable.
- If a check fails, report the failure — never describe work as done because it
  was written.
- If you are unsure whether something is in scope, ask before building.
- If the plan and the code disagree, the code is the truth and the plan is a bug.
  Say which.

---

## Comments

Comments record **what was tried and why it failed**, not what the code does.

    // BAD:  select the columns
    // GOOD: a star expands at PARSE time, so SELECT * here is not a slow
    //       query — it is a permission error raised before execution, which
    //       aborts the whole statement even against an empty table. That is
    //       the exact shape of the 500 that ran on /games for nine days.

Write it at the moment you understand the failure. That understanding does not
survive the week.

---

## Where things are

| Need | Look in |
|---|---|
| What a slice must do | `ROADMAP.md` |
| What is actually built | `STATUS.md` |
| Deferred work, and why | `BACKLOG.md` |
| Why a rule exists | this file, the constraint's own paragraph |

# Status

Legend: `[ ]` not started · `[~]` building · `[x]` done (every Definition-of-Done
point, pushed) · `[!]` **closed except for a named UI or Does clause** — see the
`**Unmet:**` rows in `BACKLOG.md`.

`[!]` does not count as done and does not count as building, and
`scripts/audit-status.mjs` refuses it **in both directions**: a `[x]` with an open
`**Unmet:**` row fails, and a `[!]` with no such row fails too. That second half
is what stops `[!]` becoming somewhere to hide.

`scripts/audit-status.mjs` checks this file against `ROADMAP.md`. A slice that
exists in one and not the other fails the build.

**Current release: R0** · slices done: 0 / 0 · building: **nothing**

---

## Slices

| Done | Slice | Route | Kind |
| ---- | ----- | ----- | ---- |
| [ ]  | **R0.1** Example slice | `/` | screen |

<!--
Keep the counter above in step with the ticked boxes — the audit compares them.
Ticking a box is a THREE-part edit: this row, the counter, and the BACKLOG row
(struck through with ~~...~~, or annotated CLOSED). That is deliberate. It forces
the choice out loud at closure time: build the clause, amend the plan's Done
line, or do not tick the box.
-->

---

## Log

Newest first. One entry per session.

An entry is a narrative, not a checklist. Record what was tried, what the premise
was, and **where the premise turned out to be wrong** — that last part is the
valuable half. A status file that only records successes teaches nothing and
quietly re-invites every mistake it does not mention.

### Template

**One bold sentence saying what changed, and the date.** Then the substance: what
was built, what it cost, what was measured. Numbers, not adjectives — "the p95 was
12.9 ms over 10,000 rows" rather than "performance is good".

**Where a previous conclusion was wrong, say so and leave the original.** Append
the correction rather than replacing the claim, so the record shows the reasoning
changed and not just the answer. A file that silently edits its own history is a
file you cannot use to reconstruct a decision.

**What is NOT done, named.** If the slice closed at `[!]`, the clause goes here in
one sentence and the detail goes in `BACKLOG.md`.

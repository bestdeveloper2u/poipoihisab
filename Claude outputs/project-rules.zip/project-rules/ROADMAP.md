# Roadmap

## Part 0 — Why the last attempt failed

Write this first, even if the last attempt was somebody else's, even if it is
short. Every rule in `CLAUDE.md` should be traceable to something here. A
constraint whose incident nobody can name is a constraint nobody obeys.

## Part 1 — Operating rules

Anything about how the project runs that is not in `CLAUDE.md`.

## Part 2 — Architecture

The stack, and the decisions that are closed. Each closed decision gets a date
and the reasoning that closed it.

## Part 3 — Data architecture

Tables, access rules, the roles that exist and what each one may do.

## Part 4 — Release plan

Which slices are in which release, and what each release is FOR.

## Part 5 — Screen by screen

The slice definitions. **This is the section `audit-status.mjs` parses**, so every
slice id must appear here exactly once, in the form `**R<n>.<n>` at the start of
its block.

Every slice is four clauses:

---

**R0.1 Example screen** · `/example`

**UI** — what is on the screen, concretely, component by component. Not "a list
of items" but "a table with sortable columns for name, status and updated-at, a
row-count above it, and an empty state naming what would fill it".

**Does** — the behavioural and architectural requirements. *This is where the hard
constraints live.* Write the ones that are easy to get wrong: "ordering is an
index scan, never a per-request recomputation"; "the guard runs at the socket
after DNS resolution, not as a string check on the hostname"; "a stale row past
its TTL renders as absent rather than as truth".

**Data** — the tables and packages it touches.

**Done** — **one falsifiable sentence.** This is the whole design.

---

### How to write a Done clause

It must name an observation someone could actually make. Good ones:

> a submitted hostname that resolves to a private address is rejected by the
> guard, proven by a test that resolves to `127.0.0.1`

> the page is correct within one sweep interval and costs one query, with the
> upstream APIs down

> changing a weight in one package moves both the published page and every stored
> value together, and rewording the prose needs no deploy

Bad ones — unfalsifiable, so always satisfied:

> the page works correctly
> performance is acceptable
> the code is well tested

**Watch for conjuncts with no subject.** "moves the published page **and every
stored value**" is unsatisfiable until something computes a stored value at all.
A Done clause with three conjuncts is three clauses, and the slice closes at `[!]`
until the last one has something to be true about.

Write these before writing code and half the design arguments never happen.

## Part 6 — Verification

How each layer is tested, and which command runs it.

# Backlog

Everything deferred, and why.

**Scope is frozen per release.** Adding a line here is free. Building it
mid-release is not. Anything that arrives mid-release becomes a line here and is
considered at the next boundary.

Without that rule this file is a wishlist. With it, it is the pressure release
valve that lets you say "not now" without losing the idea — which is what
actually stops mid-release scope reversal.

## Two kinds of row

**`**Unmet:**` rows** name a clause the plan promises and the code does not do.
They are load-bearing: `scripts/audit-status.mjs` reads them, and a slice may
wear `[!]` only while one of these names its open clause. Start the Item cell with
the literal text `**Unmet:**` — the audit matches that prefix exactly.

To release the tick when the clause is finally built, strike the row through with
`~~...~~` or write `CLOSED` in it. Do not delete it: a struck row is a record that
the gap existed and was closed, and a deleted one is a gap that was never
admitted.

**Every other row** is ordinary deferred work. It holds nothing back and never
blocks a tick.

The **Consider at** column names the slice this is FILED AGAINST — the one it
blocks, not the one that will eventually clear it. An unmet row is the reason a
tick has not moved; filing it forward leaves a slice wearing `[!]` with nothing
in the backlog explaining why.

| Item | Raised | Consider at | Note |
| ---- | ------ | ----------- | ---- |
| **Unmet:** R0.1 Done — "example clause the code does not satisfy" | 2026-01-01 | R0.1 | Why it is not built, what would build it, and what it costs to leave. Be concrete: this cell is what a reader six weeks from now uses to decide whether to promote it. If the reasoning in a row is later proved wrong, append the correction rather than editing the claim. |
